// Interface for general restaurant functionalities
interface Restaurant {
  void takeOrder(String order);
  void prepareFood(String order);
  void serveFood(String order);
}

// Interface for Cheesecake Factory specific functionalities
interface CheesecakeFactory {
  String getFamousFor(); // This could be a signature dish or service
}

// Interface for City of Miami Restaurant Regulations
interface FIURestaurant {
  boolean passesHealthInspection(); // Example regulation
}

// Class implementing all three interfaces - Specific Cheesecake Factory branch in Miami
class MiamiCheesecakeFactory implements Restaurant, CheesecakeFactory, FIURestaurant {
	boolean clean = true;
  @Override
  public void takeOrder(String order) {
    System.out.println("Taking order for " + order + " at Miami Cheesecake Factory.");
  }

  @Override
  public void prepareFood(String order) {
    System.out.println("Preparing " + order + " according to Cheesecake Factory standards.");
  }

  @Override
  public void serveFood(String order) {
    System.out.println("Serving " + order + " at your table. Enjoy!");
  }

  @Override
  public String getFamousFor() {
    return "Wide variety of cheesecakes and large portion sizes.";
  }

  @Override
  public boolean passesHealthInspection() {
	  if(clean)
		  return true; 
	  else
		  return false;
  }
}

public class FIURestaurantDemo {
  public static void main(String[] args) {
	MiamiCheesecakeFactory fiu = new MiamiCheesecakeFactory(); 
	  
    fiu.takeOrder("Chicken Madeira");
    fiu.prepareFood("Chicken Madeira");
    fiu.serveFood("Chicken Madeira");

    System.out.println("This FIU Cheesecake Factory is famous for: " + fiu.getFamousFor());
  }
}