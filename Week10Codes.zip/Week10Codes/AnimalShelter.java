class Animal {
  public void feed() {
	  System.out.println("Feeding the animal: one portion of food");
  }
}

class Dog extends Animal {
  @Override
  public void feed() {
    System.out.println("Feeding the dog: 2 cups of dog food and fresh water.");
  }
}

class Cat extends Animal {
  @Override
  public void feed() {
    System.out.println("Feeding the cat: 1 cup of cat food and water.");
  }
}

public class AnimalShelter {
	  public static void main(String[] args) {
	    Animal[] animals = {new Dog(), new Cat(), new Dog(), new Cat(), new Dog(), new Cat()};

	    // Looping through animals and calling feed polymorphically
	    for (Animal animal : animals) {
	      animal.feed();
	    }
	  }
	}