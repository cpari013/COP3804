public class FIURestaurantDemo2 {
	  public static void main(String[] args) {
	    Restaurant restaurant = new MiamiCheesecakeFactory(); // Polymorphism - reference to interface

	    restaurant.takeOrder("Chicken Madeira");
	    restaurant.prepareFood("Chicken Madeira");
	    restaurant.serveFood("Chicken Madeira");

	    MiamiCheesecakeFactory miamiCF = (MiamiCheesecakeFactory) restaurant; // Downcasting to access specific method
	    System.out.println("This Cheesecake Factory is famous for: " + miamiCF.getFamousFor());
	  }
	}