public class PowerFunction {

    public static int power(int base, int exponent) {
        if (exponent == 0) {
            return 1; // Base case: any number raised to the power of 0 is 1
        } else {
            return base * power(base, exponent - 1); // Recursive step: multiply base by itself exponent times
        }
    }

    public static void main(String[] args) {
        int base = 2;
        int exponent = 3;
        System.out.println(base + " raised to the power of " + exponent + " is: " + power(base, exponent));
    }
}