import java.util.Scanner;

/**
   This program demonstrates the recursive
   factorial method.
*/

public class FactorialDemo
{
   public static void main(String[] args)
   {
      Scanner keyboard = new Scanner(System.in);
      int number;     // To hold a number
      
      // Get a number from the user.
      System.out.println("Enter a number.");
      number = keyboard.nextInt();
      
      // Display the factorial of the number.
      System.out.println(number + "! is " + factorial(number));

   }
   
   /**
      The factorial method uses recursion to calculate
      the factorial of its argument, which is assumed
      to be a nonnegative number.
      @param n The number to use in the calculation.
      @return The factorial of n.
   */
   
   private static int factorial(int n)
   {
      if (n == 0)
         return 1;   // Base case
      else
         return n * factorial(n - 1);
   }
}