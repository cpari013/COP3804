import java.util.Scanner;

/**
   This program demonstrates the FinalExam class,
   which extends the GradedActivity class.
*/

public class FinalExamDemo
{
   public static void main(String[] args)
   {
      Scanner scanner = new Scanner(System.in); // Create a Scanner object for input
      
      int questions;    // Number of questions
      int missed;       // Number of questions missed

      // Get the number of questions on the exam.
      System.out.println("How many questions are on the final exam?");
      questions = scanner.nextInt();

      // Get the number of questions the student missed.
      System.out.println("How many questions did the student miss?");
      missed = scanner.nextInt();

      // Create a FinalExam object.
      FinalExam exam = new FinalExam(questions, missed);

      // Display the test results.
      System.out.println("Each question counts " + exam.getPointsEach() +
           " points.\nThe exam score is " +
           exam.getScore() + "\nThe exam grade is " +
           exam.getGrade());

      scanner.close(); // Close the scanner to prevent resource leak
   }
}