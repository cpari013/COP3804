import java.util.Scanner;

/**
   This program demonstrates the GradedActivity 
   class.
*/

public class GradeDemo
{
   public static void main(String[] args)
   {
      Scanner scanner = new Scanner(System.in); // Create a Scanner object for input
      
      double testScore;    // A test score
      
      // Create a GradedActivity object.
      GradedActivity grade = new GradedActivity();

      // Get a test score.
      System.out.println("Enter a numeric test score:");
      testScore = scanner.nextDouble();

      // Store the score in the grade object.
      grade.setScore(testScore);
      
      // Display the letter grade for the score.
      System.out.println("The grade for that test is " + grade.getGrade());

      scanner.close(); // Close the scanner to prevent resource leak
   }
}