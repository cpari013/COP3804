public class SuperClass2
{
   /**
      Constructor #1
   */

   public SuperClass2()
   {
      System.out.println("This is the superclass " +
                          "no-arg constructor.");
   }

   /**
      Constructor #2
   */

   public SuperClass2(int arg)
   {
      System.out.println("The following argument " +
                   "was passed to the superclass " +
                   "constructor: " + arg);
   }
}