/**
   This program demonstrates how a superclass
   constructor is called with the super key word.
*/

public class ConstructorDemo2
{
   public static void main(String[] args)
   {
      SubClass2 obj = new SubClass2();
   }
}